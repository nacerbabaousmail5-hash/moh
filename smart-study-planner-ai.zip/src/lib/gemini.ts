import { GoogleGenAI, Type } from "@google/genai";
import { Subject, DayPlan, PracticeQuestion } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function generateStudyPlan(
  subjects: Subject[],
  examDate: string,
  dailyHours: number
): Promise<DayPlan[]> {
  const prompt = `You are a professional study planner. Create a detailed daily study plan for a student preparing for an exam on ${examDate}. 
  The student can study for ${dailyHours} hours per day.
  Subjects with current levels:
  ${subjects.map(s => `- ${s.name}: ${s.level}`).join('\n')}
  
  Requirements:
  1. Generate a plan for the next 7 days.
  2. Each day should have 2-4 tasks.
  3. Total duration of tasks per day should roughly equal ${dailyHours} hours.
  4. Prioritize "beginner" level subjects with more "deep-dive" sessions.
  5. Include "review" and "practice" sessions for all subjects.
  6. Return the data in valid JSON format according to the schema provided.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            date: { type: Type.STRING, description: "ISO date string" },
            tasks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  subjectId: { type: Type.STRING },
                  topic: { type: Type.STRING },
                  durationMinutes: { type: Type.NUMBER },
                  completed: { type: Type.BOOLEAN },
                  type: { type: Type.STRING, enum: ["review", "practice", "deep-dive"] }
                },
                required: ["id", "subjectId", "topic", "durationMinutes", "completed", "type"]
              }
            }
          },
          required: ["date", "tasks"]
        }
      }
    }
  });

  return JSON.parse(response.text || "[]");
}

export async function generatePracticeQuestions(
  subjectName: string,
  topic: string
): Promise<PracticeQuestion[]> {
  const prompt = `Generate 5 multiple-choice practice questions for the topic "${topic}" in the subject "${subjectName}". 
  Include correct answers and explanations. Match the difficulty to a high school/Baccalaureate level.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            question: { type: Type.STRING },
            options: { type: Type.ARRAY, items: { type: Type.STRING } },
            correctAnswer: { type: Type.NUMBER, description: "Index of the correct answer (0-3)" },
            explanation: { type: Type.STRING }
          },
          required: ["question", "options", "correctAnswer", "explanation"]
        }
      }
    }
  });

  return JSON.parse(response.text || "[]");
}
