export type SubjectLevel = 'beginner' | 'intermediate' | 'advanced';

export interface Subject {
  id: string;
  name: string;
  level: SubjectLevel;
  color: string;
}

export interface DayPlan {
  date: string; // ISO format
  tasks: Task[];
}

export interface Task {
  id: string;
  subjectId: string;
  topic: string;
  durationMinutes: number;
  completed: boolean;
  type: 'review' | 'practice' | 'deep-dive';
}

export interface PracticeQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface UserProfile {
  subjects: Subject[];
  examDate: string;
  dailyStudyHours: number;
  onboarded: boolean;
}

export interface AppState {
  profile: UserProfile;
  plans: DayPlan[];
  points: number;
  streak: number;
  lastActive: string;
}
