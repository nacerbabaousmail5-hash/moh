import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Coffee, BookOpen } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface PomodoroTimerProps {
  onComplete?: () => void;
}

export default function PomodoroTimer({ onComplete }: PomodoroTimerProps) {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [isBreak, setIsBreak] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      handleTimerComplete();
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, timeLeft]);

  const handleTimerComplete = () => {
    setIsActive(false);
    if (!isBreak) {
      setIsBreak(true);
      setTimeLeft(5 * 60);
      onComplete?.();
    } else {
      setIsBreak(false);
      setTimeLeft(25 * 60);
    }
    // Browser notification could go here if permissions allowed
  };

  const toggleTimer = () => setIsActive(!isActive);
  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(isBreak ? 5 * 60 : 25 * 60);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = isBreak ? (5 * 60 - timeLeft) / (5 * 60) : (25 * 60 - timeLeft) / (25 * 60);

  return (
    <div className="flex flex-col items-center p-6 glass-card rounded-3xl w-full max-w-sm">
      <div className="flex items-center gap-2 mb-6">
        {isBreak ? (
          <Coffee className="text-emerald-500 w-5 h-5" />
        ) : (
          <BookOpen className="text-blue-500 w-5 h-5" />
        )}
        <span className="font-semibold text-slate-700 uppercase tracking-wider text-sm">
          {isBreak ? 'وقت الراحة' : 'جلسة دراسة'}
        </span>
      </div>

      <div className="relative w-48 h-48 flex items-center justify-center mb-8">
        <svg className="w-full h-full transform -rotate-90">
          <circle
            cx="96"
            cy="96"
            r="88"
            fill="transparent"
            stroke="currentColor"
            strokeWidth="8"
            className="text-slate-100"
          />
          <motion.circle
            cx="96"
            cy="96"
            r="88"
            fill="transparent"
            stroke="currentColor"
            strokeWidth="8"
            strokeDasharray={552.92} // 2 * PI * 88
            initial={{ strokeDashoffset: 552.92 }}
            animate={{ strokeDashoffset: 552.92 * (1 - progress) }}
            className={isBreak ? "text-emerald-500" : "text-blue-500"}
            style={{ strokeLinecap: 'round' }}
          />
        </svg>
        <span className="absolute font-mono text-4xl font-bold text-slate-800">
          {formatTime(timeLeft)}
        </span>
      </div>

      <div className="flex gap-4">
        <button
          onClick={toggleTimer}
          className={`p-4 rounded-2xl transition-all shadow-md ${
            isActive 
              ? 'bg-slate-200 text-slate-700 hover:bg-slate-300' 
              : 'bg-blue-600 text-white hover:bg-blue-700 hover:scale-105 active:scale-95'
          }`}
        >
          {isActive ? <Pause fill="currentColor" /> : <Play fill="currentColor" />}
        </button>
        <button
          onClick={resetTimer}
          className="p-4 rounded-2xl bg-white text-slate-500 border border-slate-200 hover:bg-slate-50 transition-all active:scale-95"
        >
          <RotateCcw />
        </button>
      </div>
    </div>
  );
}
