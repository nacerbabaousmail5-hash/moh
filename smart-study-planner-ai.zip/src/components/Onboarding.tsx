import React, { useState } from 'react';
import { Subject, UserProfile, SubjectLevel } from '../types';
import { Plus, Trash2, Rocket, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

interface OnboardingProps {
  onComplete: (profile: UserProfile) => void;
}

const SUBJECT_COLORS = [
  'bg-blue-500', 'bg-emerald-500', 'bg-rose-500', 'bg-amber-500', 
  'bg-purple-500', 'bg-cyan-500', 'bg-indigo-500'
];

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [newSubject, setNewSubject] = useState('');
  const [examDate, setExamDate] = useState('');
  const [hours, setHours] = useState(4);
  const [step, setStep] = useState(1);

  const addSubject = () => {
    if (!newSubject.trim()) return;
    const subject: Subject = {
      id: Math.random().toString(36).substr(2, 9),
      name: newSubject.trim(),
      level: 'intermediate',
      color: SUBJECT_COLORS[subjects.length % SUBJECT_COLORS.length]
    };
    setSubjects([...subjects, subject]);
    setNewSubject('');
  };

  const removeSubject = (id: string) => {
    setSubjects(subjects.filter(s => s.id !== id));
  };

  const updateLevel = (id: string, level: SubjectLevel) => {
    setSubjects(subjects.map(s => s.id === id ? { ...s, level } : s));
  };

  const handleSubmit = () => {
    if (subjects.length === 0 || !examDate) return;
    onComplete({
      subjects,
      examDate,
      dailyStudyHours: hours,
      onboarded: true
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-50" dir="rtl">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-xl glass-card rounded-3xl p-8 shadow-xl"
      >
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Sparkles className="text-blue-600 w-8 h-8" />
          </div>
          <h1 className="text-3xl font-bold text-slate-800 mb-2">أهلاً بك في Smart Study</h1>
          <p className="text-slate-500">لنبني خطتك الدراسية المثالية في دقائق</p>
        </div>

        {step === 1 && (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">ما هي المواد التي تدرسها؟</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newSubject}
                  onChange={(e) => setNewSubject(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addSubject()}
                  placeholder="اسم المادة (مثلاً: رياضيات)"
                  className="flex-1 px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                />
                <button
                  onClick={addSubject}
                  className="bg-blue-600 text-white p-3 rounded-xl hover:bg-blue-700 transition-all"
                >
                  <Plus />
                </button>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {subjects.map((s) => (
                <div key={s.id} className="flex items-center gap-2 bg-white border border-slate-200 px-3 py-2 rounded-xl group">
                  <div className={`w-3 h-3 rounded-full ${s.color}`} />
                  <span className="text-slate-700 font-medium">{s.name}</span>
                  <button onClick={() => removeSubject(s.id)} className="text-slate-400 hover:text-rose-500 transition-colors">
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>

            <button
              disabled={subjects.length === 0}
              onClick={() => setStep(2)}
              className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 disabled:opacity-50 transition-all mt-4"
            >
              الخطوة التالية
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <label className="block text-sm font-semibold text-slate-700">قيم مستواك في كل مادة:</label>
            <div className="space-y-4 max-h-60 overflow-y-auto pr-2">
              {subjects.map((s) => (
                <div key={s.id} className="flex items-center justify-between p-3 bg-white border border-slate-100 rounded-xl">
                  <span className="font-medium text-slate-800">{s.name}</span>
                  <div className="flex gap-1">
                    {(['beginner', 'intermediate', 'advanced'] as SubjectLevel[]).map((l) => (
                      <button
                        key={l}
                        onClick={() => updateLevel(s.id, l)}
                        className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                          s.level === l 
                            ? 'bg-blue-600 text-white shadow-md' 
                            : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                        }`}
                      >
                        {l === 'beginner' ? 'مبتدئ' : l === 'intermediate' ? 'متوسط' : 'متقدم'}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">تاريخ الامتحان الأهم:</label>
              <input
                type="date"
                value={examDate}
                onChange={(e) => setExamDate(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">كم ساعة تستطيع الدراسة يومياً؟ ({hours} ساعات)</label>
              <input
                type="range"
                min="1"
                max="12"
                value={hours}
                onChange={(e) => setHours(parseInt(e.target.value))}
                className="w-full accent-blue-600"
              />
            </div>

            <div className="flex gap-4 pt-4">
              <button
                onClick={() => setStep(1)}
                className="flex-1 py-4 border border-slate-200 text-slate-600 rounded-2xl font-bold hover:bg-slate-50 transition-all"
              >
                رجوع
              </button>
              <button
                onClick={handleSubmit}
                className="flex-1 py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-200 transition-all flex items-center justify-center gap-2"
              >
                انطلاق <Rocket size={20} />
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}
