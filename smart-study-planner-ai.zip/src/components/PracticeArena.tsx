import React, { useState } from 'react';
import { PracticeQuestion } from '../types';
import { CheckCircle2, XCircle, Brain, RefreshCw, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';

interface PracticeArenaProps {
  questions: PracticeQuestion[];
  onFinish: () => void;
  isLoading?: boolean;
}

export default function PracticeArena({ questions, onFinish, isLoading }: PracticeArenaProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center">
        <RefreshCw className="animate-spin text-blue-500 w-12 h-12 mb-4" />
        <h3 className="text-xl font-bold text-slate-800">جاري توليد الأسئلة بالذكاء الاصطناعي...</h3>
        <p className="text-slate-500">من فضلك انتظر لحظة</p>
      </div>
    );
  }

  const currentQuestion = questions[currentIndex];

  const handleSelect = (index: number) => {
    if (selectedOption !== null) return;
    setSelectedOption(index);
    setShowExplanation(true);
    if (index === currentQuestion.correctAnswer) {
      setScore(score + 1);
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
  };

  const nextQuestion = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setSelectedOption(null);
      setShowExplanation(false);
    } else {
      onFinish();
    }
  };

  return (
    <div className="max-w-2xl mx-auto py-8" dir="rtl">
      <div className="mb-8 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center">
            <Brain className="text-indigo-600" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800">اختبار ذكي</h2>
            <p className="text-sm text-slate-500">سؤال {currentIndex + 1} من {questions.length}</p>
          </div>
        </div>
        <div className="bg-blue-50 px-4 py-2 rounded-full font-bold text-blue-700">
          النتيجة: {score} / {questions.length}
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="glass-card rounded-3xl p-8"
        >
          <h3 className="text-2xl font-bold text-slate-800 mb-8 leading-tight">
            {currentQuestion.question}
          </h3>

          <div className="grid gap-4">
            {currentQuestion.options.map((option, idx) => {
              const isCorrect = idx === currentQuestion.correctAnswer;
              const isSelected = selectedOption === idx;
              const showResult = selectedOption !== null;

              return (
                <button
                  key={idx}
                  onClick={() => handleSelect(idx)}
                  disabled={showResult}
                  className={`p-5 rounded-2xl text-right transition-all border-2 text-lg font-medium flex items-center justify-between ${
                    showResult
                      ? isCorrect
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-700'
                        : isSelected
                        ? 'bg-rose-50 border-rose-500 text-rose-700'
                        : 'bg-white border-slate-100 text-slate-400'
                      : 'bg-white border-slate-100 text-slate-700 hover:border-blue-500 hover:bg-blue-50 active:scale-[0.98]'
                  }`}
                >
                  <span>{option}</span>
                  {showResult && (
                    isCorrect ? <CheckCircle2 className="text-emerald-600" /> : isSelected ? <XCircle className="text-rose-600" /> : null
                  )}
                </button>
              );
            })}
          </div>

          <AnimatePresence>
            {showExplanation && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="mt-8 p-6 bg-slate-50 rounded-2xl border border-slate-200"
              >
                <div className="font-bold text-slate-800 mb-2">التفسير:</div>
                <p className="text-slate-600 leading-relaxed">{currentQuestion.explanation}</p>
                <button
                  onClick={nextQuestion}
                  className="mt-6 w-full py-4 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all flex items-center justify-center gap-2"
                >
                  {currentIndex === questions.length - 1 ? 'إنهاء' : 'السؤال التالي'}
                  <ChevronRight size={20} className="rotate-180" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
