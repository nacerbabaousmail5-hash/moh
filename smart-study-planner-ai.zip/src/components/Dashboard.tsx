import React, { useState, useEffect } from 'react';
import { UserProfile, DayPlan, Task, PracticeQuestion } from '../types';
import { 
  Calendar, CheckCircle, Clock, Layout, 
  Menu, PlayCircle, Settings, Award, 
  ChevronLeft, ChevronRight, Zap, Target, Brain
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import PomodoroTimer from './PomodoroTimer';
import PracticeArena from './PracticeArena';
import { generateStudyPlan, generatePracticeQuestions } from '../lib/gemini';
import { format, addDays, isSameDay } from 'date-fns';
import { ar } from 'date-fns/locale';

interface DashboardProps {
  profile: UserProfile;
}

export default function Dashboard({ profile }: DashboardProps) {
  const [plans, setPlans] = useState<DayPlan[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [isLoading, setIsLoading] = useState(false);
  const [activePracticeQuestions, setActivePracticeQuestions] = useState<PracticeQuestion[] | null>(null);
  const [isGeneratingPractice, setIsGeneratingPractice] = useState(false);

  useEffect(() => {
    const savedPlans = localStorage.getItem('study_plans');
    if (savedPlans) {
      setPlans(JSON.parse(savedPlans));
    } else {
      handleGeneratePlan();
    }
  }, []);

  const handleGeneratePlan = async () => {
    setIsLoading(true);
    try {
      const newPlans = await generateStudyPlan(profile.subjects, profile.examDate, profile.dailyStudyHours);
      setPlans(newPlans);
      localStorage.setItem('study_plans', JSON.stringify(newPlans));
    } catch (error) {
      console.error('Failed to generate plan', error);
    } finally {
      setIsLoading(false);
    }
  };

  const currentDayPlan = plans.find(p => isSameDay(new Date(p.date), selectedDate));

  const toggleTask = (taskId: string) => {
    const updatedPlans = plans.map(day => ({
      ...day,
      tasks: day.tasks.map(task => 
        task.id === taskId ? { ...task, completed: !task.completed } : task
      )
    }));
    setPlans(updatedPlans);
    localStorage.setItem('study_plans', JSON.stringify(updatedPlans));
  };

  const startPractice = async (task: Task) => {
    setIsGeneratingPractice(true);
    setActivePracticeQuestions([]); // show loading in arena
    try {
      const subject = profile.subjects.find(s => s.id === task.subjectId);
      const questions = await generatePracticeQuestions(subject?.name || 'Education', task.topic);
      setActivePracticeQuestions(questions);
    } catch (error) {
      console.error('Failed to generate questions', error);
      setActivePracticeQuestions(null);
    } finally {
      setIsGeneratingPractice(false);
    }
  };

  const getDayName = (date: Date) => format(date, 'EEEE', { locale: ar });
  const getFormattedDate = (date: Date) => format(date, 'd MMMM', { locale: ar });

  if (activePracticeQuestions) {
    return (
      <div className="min-h-screen bg-slate-50 p-4 pt-10">
        <button 
          onClick={() => setActivePracticeQuestions(null)}
          className="mb-6 flex items-center gap-2 text-slate-500 hover:text-slate-800 transition-colors bg-white px-4 py-2 rounded-xl border border-slate-200"
        >
          <ChevronRight size={18} /> العودة للوحة التحكم
        </button>
        <PracticeArena 
          questions={activePracticeQuestions} 
          isLoading={isGeneratingPractice}
          onFinish={() => setActivePracticeQuestions(null)} 
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] pb-20" dir="rtl">
      {/* Header */}
      <header className="bg-white border-b border-slate-100 px-6 py-4 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 study-gradient rounded-xl flex items-center justify-center text-white shadow-lg">
              <Zap size={22} fill="white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-800">Smart Study</h1>
              <p className="text-xs font-medium text-slate-500">منظمك الذكي</p>
            </div>
          </div>
          <div className="flex gap-2">
            <div className="bg-amber-50 text-amber-700 px-4 py-2 rounded-xl flex items-center gap-2 text-sm font-bold border border-amber-100">
              <Award size={18} /> 450 نقطة
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Main Content (Tasks) */}
          <div className="lg:col-span-8 space-y-10">
            {/* Calendar Strip */}
            <section>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-slate-800">خطة المراجعة</h2>
                <div className="flex gap-2">
                  <button onClick={() => setSelectedDate(addDays(selectedDate, -1))} className="p-2 hover:bg-white rounded-lg transition-colors border border-slate-100">
                    <ChevronRight size={20} />
                  </button>
                  <button onClick={() => setSelectedDate(addDays(selectedDate, 1))} className="p-2 hover:bg-white rounded-lg transition-colors border border-slate-100">
                    <ChevronLeft size={20} />
                  </button>
                </div>
              </div>
              
              <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
                {[...Array(7)].map((_, i) => {
                  const date = addDays(new Date(), i);
                  const isSelected = isSameDay(date, selectedDate);
                  return (
                    <button
                      key={i}
                      onClick={() => setSelectedDate(date)}
                      className={`flex-shrink-0 w-24 h-28 rounded-2xl flex flex-col items-center justify-center transition-all ${
                        isSelected 
                          ? 'bg-blue-600 text-white shadow-xl translate-y-[-4px]' 
                          : 'bg-white text-slate-600 border border-slate-100 hover:border-blue-200'
                      }`}
                    >
                      <span className="text-[10px] uppercase font-bold tracking-widest mb-2 opacity-80">
                        {getDayName(date).slice(0, 3)}
                      </span>
                      <span className="text-2xl font-black">{date.getDate()}</span>
                    </button>
                  );
                })}
              </div>
            </section>

            {/* Task List */}
            <section className="space-y-4">
              <div className="flex justify-between items-end mb-4">
                <div>
                  <h3 className="text-lg font-bold text-slate-800">مهام {getDayName(selectedDate)}</h3>
                  <p className="text-sm text-slate-500">{getFormattedDate(selectedDate)}</p>
                </div>
                {isLoading && <span className="text-xs text-blue-600 animate-pulse font-bold">جاري التحديث...</span>}
              </div>

              {currentDayPlan?.tasks.map((task, idx) => {
                const subject = profile.subjects.find(s => s.id === task.subjectId);
                return (
                  <motion.div
                    key={task.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className={`p-6 rounded-3xl border border-slate-100 transition-all flex items-center justify-between gap-4 ${
                      task.completed ? 'bg-emerald-50/30 grayscale-[0.5]' : 'bg-white hover:shadow-md'
                    }`}
                  >
                    <div className="flex items-center gap-5 flex-1">
                      <button 
                        onClick={() => toggleTask(task.id)}
                        className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all ${
                          task.completed 
                            ? 'bg-emerald-500 border-emerald-500 text-white' 
                            : 'border-slate-200 text-transparent hover:border-blue-400'
                        }`}
                      >
                        <CheckCircle size={20} fill="currentColor" />
                      </button>
                      
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`w-2 h-2 rounded-full ${subject?.color || 'bg-slate-400'}`} />
                          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                            {subject?.name || 'مادة'} • {task.type === 'review' ? 'مراجعة' : task.type === 'practice' ? 'تمارين' : 'دراسة عميقة'}
                          </span>
                        </div>
                        <h4 className={`text-lg font-bold ${task.completed ? 'text-slate-400 line-through' : 'text-slate-800'}`}>
                          {task.topic}
                        </h4>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1 text-slate-400 text-sm font-medium ml-4">
                        <Clock size={16} />
                        {task.durationMinutes} د
                      </div>
                      
                      {task.type === 'practice' && !task.completed && (
                        <button 
                          onClick={() => startPractice(task)}
                          className="bg-indigo-50 text-indigo-600 px-4 py-2 rounded-xl text-sm font-bold hover:bg-indigo-100 transition-all flex items-center gap-2"
                        >
                          <Brain size={16} /> ابدأ التحدي
                        </button>
                      )}
                    </div>
                  </motion.div>
                );
              })}

              {!currentDayPlan && !isLoading && (
                <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-200">
                  <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Calendar className="text-slate-300" size={32} />
                  </div>
                  <p className="text-slate-500 font-medium">لا توجد خطة لهذا اليوم حتى الآن</p>
                  <button 
                    onClick={handleGeneratePlan}
                    className="mt-4 text-blue-600 font-bold hover:underline"
                  >
                    توليد خطة جديدة بالذكاء الاصطناعي
                  </button>
                </div>
              )}
            </section>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-4 space-y-8">
            {/* Pomodoro */}
            <section>
              <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                <Target className="text-blue-600" size={20} /> تركيز بومودورو
              </h3>
              <PomodoroTimer onComplete={() => console.log('Session done!')} />
            </section>

            {/* Quick Stats */}
            <section className="glass-card rounded-3xl p-6 space-y-6">
              <h3 className="font-bold text-slate-800 mb-2">إحصائيات التقدم</h3>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center text-sm font-medium">
                  <span className="text-slate-500">إنجاز المهام اليومية</span>
                  <span className="text-blue-600">65%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-blue-600 h-full rounded-full" style={{ width: '65%' }} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-100 text-center">
                  <div className="text-emerald-600 font-black text-2xl">3</div>
                  <div className="text-emerald-700 text-[10px] font-bold uppercase tracking-wider">أيام متتالية</div>
                </div>
                <div className="bg-purple-50 p-4 rounded-2xl border border-purple-100 text-center">
                  <div className="text-purple-600 font-black text-2xl">12</div>
                  <div className="text-purple-700 text-[10px] font-bold uppercase tracking-wider">ساعة مراجعة</div>
                </div>
              </div>
            </section>

            {/* AI Assistant Insight */}
            <section className="bg-slate-900 rounded-3xl p-6 text-white relative overflow-hidden group">
              <div className="relative z-10">
                <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center mb-4">
                  <Sparkles size={16} />
                </div>
                <h4 className="font-bold mb-2">نصيحة الذكاء الاصطناعي</h4>
                <p className="text-slate-400 text-sm leading-relaxed">
                  يلاحظ نظامنا أنك أسرع في دروس الرياضيات. ربما يمكنك تقليص وقتها غداً وزيادة حصة الفلسفة!
                </p>
              </div>
              <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-blue-500/20 rounded-full blur-2xl group-hover:bg-blue-500/30 transition-all" />
            </section>
          </div>
        </div>
      </main>
    </div>
  );
}

function Sparkles({ size }: { size: number }) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z" />
      <path d="M5 3v4" /><path d="M19 17v4" /><path d="M3 5h4" /><path d="M17 19h4" />
    </svg>
  );
}
